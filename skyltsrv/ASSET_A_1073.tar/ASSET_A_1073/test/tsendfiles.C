#include <fstream.h>
#include <sockinet.h>
#include <pwd.h>
#include <stdio.h>
#include <unistd.h>

static int send_cmd(iosockstream&, const char* cmd=0);

main(int ac, char** av)
{
    if (ac < 3) {
	cerr << "USAGE: " << av[0] << " recipient-email-addr files...\n";
	return 1;
    }
    
    char         rcpt[512];
    char         sender[512];
    iosockinet   sio(sockbuf::sock_stream);
    sio->connect(sio->localhost(), "smtp", "tcp");
    
    send_cmd(sio, 0);
    send_cmd(sio, "HELO");
    
    
    sprintf(rcpt, "RCPT TO:%s", av[1]);
    
    passwd* pw = getpwuid( getuid() );
    sprintf(sender, "MAIL FROM:<%s@%s>", pw->pw_name, sio->localhost());
    
    for (int i=2; i < ac; i++) {
	send_cmd(sio, sender);
	send_cmd(sio, rcpt);
	send_cmd(sio, "DATA");
	sio << "\r\n------------------------" << av[i]
	    << "------------------------\r\n" << flush;
	
	ifstream cin(av[i]);
	char buf[512];
	while(cin.getline(buf, 511)) {
	    if (buf[0] == '.' && buf[1] == 0) {
		cerr << av[0]
		     << ": char '.' on a line of its own\n";
		return 1;
	    }
	    sio <<  buf << "\r\n" << flush;
	}
	sio << "\r\n.\r\n" << flush;
	send_cmd(sio, 0);
    }
    send_cmd(sio, "QUIT");
}

int send_cmd(iosockstream& s, const char* cmd)
{
    char buf[256];
    if (cmd) s << cmd << "\r\n" << flush;
    s.getline(buf, 255);
    cout << buf << endl;
    return 0;
}
