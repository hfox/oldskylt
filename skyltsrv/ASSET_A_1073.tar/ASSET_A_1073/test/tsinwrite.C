// tsinwrite.cc. Test for -*- C++ -*- socket library
// Copyright (C) 1992,1993,1994 Gnanasekaran Swaminathan <gs4t@virginia.edu>
// 
// Permission is granted to use at your own risk and distribute this software
// in source and binary forms provided the above copyright
// notice and this paragraph are preserved on all copies.
// This software is provided "as is" with no express or implied warranty.
//
// Version: 17Oct95 1.10

#include <sockinet.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

int main(int ac, char** av)
{
    if (ac < 3) {
	cerr << "USAGE: " << av[0] << " machinename port "
	     << "format-string data...\n";
	return 1;
    }
    
    iosockinet	sio (sockbuf::sock_stream);
    sio->connect(av [1], atoi (av [2]));
    //  sio->shutdown(sockbuf::shut_read);
    
    // 	cout << "local port = " << sio->localport() << endl
    // 	     << " peer port = " << sio->peerport() << endl
    // 	     << "local host = " << sio->localhost() << endl
    // 	     << " peer host = " << sio->peerhost() << endl;
    
    av += 3;
    while (*av) sio << *av++ << ' '; // space is neccessary
    sio << endl; // endl to flush output
    
    char buf[256];
    while (sio >> buf) cout << buf << ' ';
    cout << endl;
    
    
    // 	sio << "%f%d%c " // space is necessary
    // 	    << 236.9 << ' '
    // 	    << 56 << ' '
    // 	    << 'c' << endl; // endl to flush output

    return 0;
}
