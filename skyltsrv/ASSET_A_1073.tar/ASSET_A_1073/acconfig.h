/* Define if extern "C" is needed arround include files */
#undef EXTERN_C_BEGIN
#undef EXTERN_C_END

/* Define if you have char* _sys_siglist[] */
#undef SYS_SIGLIST

/* Define SA_RESTART if it is not defined in sys/signal.h */
#undef SA_RESTART

/* Define if you have libg++ */
#undef _S_LIBGXX

@BOTTOM@
#include <local.h>
